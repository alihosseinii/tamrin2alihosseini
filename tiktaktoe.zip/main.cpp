#include "tiktaktoe.cpp"
int main() {
    tiktaktoe game;
    game.play();
}
