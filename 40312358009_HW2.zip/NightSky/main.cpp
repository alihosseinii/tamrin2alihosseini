#include "sky.hpp"

int main() {
    Sky sky;
    sky.addStar(Star(100, 200));
    sky.render();
    return 0;
}
