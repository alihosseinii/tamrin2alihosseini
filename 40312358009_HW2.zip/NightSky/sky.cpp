#include "star.hpp"

Star::Star(int x, int y) : x(x), y(y) {}

bool Star::isValid() const {
    return x >= 0 && x <= 800 && y >= 0 && y <= 600;
}
