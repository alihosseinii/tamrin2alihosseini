#ifndef STAR_HPP
#define STAR_HPP

class Star {
private:
    int x;
    int y;
    
public:
    Star(int x, int y);
    bool isValid() const;
};
#endif
