#ifndef PATIENT_HPP
#define PATIENT_HPP
#include <string>

class Patient {
private:
    std::string name;
    double temp;
    int heartRate;
    
public:
    Patient(std::string name, double temp, int hr);
    ~Patient();
    void encryptData();
};
#endif
