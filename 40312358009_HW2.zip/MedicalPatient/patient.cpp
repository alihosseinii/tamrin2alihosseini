#include "patient.hpp"
#include <iostream>

Patient::Patient(std::string name, double temp, int hr) 
    : name(name), temp(temp), heartRate(hr) {
    if (temp < 36.0 || temp > 37.5 || hr < 60 || hr > 100) {
        throw std::invalid_argument("Abnormal vital signs!");
    }
}

Patient::~Patient() {
    encryptData();
}

void Patient::encryptData(){
    for (char& c : name) {
        c ^= 0x55;
    }
}
