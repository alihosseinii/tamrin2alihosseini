#include "hospital.hpp"

void Hospital::addPatient(const Patient& patient) {
    patients.push_back(patient);
}
