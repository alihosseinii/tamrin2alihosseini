#include "hospital.hpp"

int main() {
    Hospital hospital;
    Patient p1("John", 36.6, 80);
    hospital.addPatient(p1);
    return 0;
}
