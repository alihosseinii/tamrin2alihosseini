#include "game.hpp"

void Game::addCharacter(const Character& character) {
    characters.push_back(character);
}

void Game::printCharacters() const {
    for (const auto& c : characters) {
        c.printSkills();
    }
}
