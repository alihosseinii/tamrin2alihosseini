#ifndef CHARACTER_HPP
#define CHARACTER_HPP
#include <string>
#include <map>

using namespace std;

class Character {
private:
    string name;
    int health;
    int power;
    map<string, int> skills;
    
public:
    Character(string name, int health, int power);
    void addSkill(string skill, int level);
    void printSkills() const;
};
#endif
