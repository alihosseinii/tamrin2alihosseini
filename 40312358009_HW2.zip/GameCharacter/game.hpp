#ifndef GAME_HPP
#define GAME_HPP
#include <vector>
#include "character.hpp"

class Game{
private:
    vector<Character> characters;
    
public:
    void addCharacter(const Character& character);
    void printCharacters() const;
};
#endif
