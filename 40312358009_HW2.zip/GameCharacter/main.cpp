#include "game.hpp"

int main() {
    Game game;
    Character hero("Hero", 100, 50);
    hero.addSkill("Sword", 10);
    
    game.addCharacter(hero);
    game.printCharacters();
    
    return 0;
}
