#include "character.hpp"
#include <iostream>

Character::Character(string name, int health, int power): name(name), health(health), power(power) {}

void Character::addSkill(string skill, int level) {
    skills[skill] = level;
}

void Character::printSkills() const {
    for (const auto& [skill, level] : skills) {
        cout << skill << ": Level " << level << endl;
    }
}
