#ifndef GPS_HPP
#define GPS_HPP

class GPS {
private:
    double latitude;
    double longitude;

public:
    GPS(double lat, double lon);
    bool isValid() const;
    ~GPS();
};

#endif
