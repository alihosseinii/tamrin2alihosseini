#include <iostream>
#include "gps.hpp"

using namespace std;

GPS::GPS(double lat, double lon) : latitude(lat), longitude(lon) {
    if (!isValid()) {
        throw invalid_argument("Invalid GPS coordinates!");
    }
}

GPS::~GPS() {
    cout << "Last position: Lat=" << latitude << ", Lon=" << longitude << endl;
}

bool GPS::isValid() const {
    return (latitude >= -90 && latitude <= 90) && (longitude >= -180 && longitude <= 180);
}
