#include "gps.hpp"

int main() {
    GPS location((double)35.6895,(double) 139.6917); 
    return 0;
}
