#include "event.hpp"
#include <iostream>

using namespace std;

event:: event(const string& eventname, int start, int end) : name(eventname) , starttime(start) , endtime(end) {
    if (end < start ){
        throw invalid_argument("end time must be after start time");
    }
}

event::~event(){
    cout << "event \"" << name << "\" has been deleted \n";
}

string event::getname() const {
    return name;
}

int event::getstarttime() const {
    return starttime;
}

int event::getendtime() const {
    return endtime;
}

bool event::isExpired() const {
    return time(nullptr) > endtime; 
}