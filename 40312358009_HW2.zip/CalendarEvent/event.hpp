#ifndef event_hpp
#define event_hpp

#include <string>

using namespace std;

class event {
    private: 
    string name;
    int starttime;
    int endtime;

    public:
    event(const string& n, int start, int end);
    ~event();
    string getname() const;
    int getstarttime() const;
    int getendtime() const;

    bool isExpired() const;
};


#endif