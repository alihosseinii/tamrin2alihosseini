#include "calendar.hpp"
#include <iostream>

using namespace std;

Calendar::~Calendar() {
    for (event* event : events) {
        delete event;
    }
}

void Calendar::addEvent (const string& name, int start, int end) {
    for (const auto& event : events) {
        if ((start >= event->getstarttime() && start < event->getendtime()) ||
            (end > event->getstarttime() && end <= event->getendtime())) {
            cout << "Event conflict detected. Cannot add event: " << name << "\n";
            return;
        }
    }
    events.push_back(new event(name, start, end));
    cout << "Event added: " << name << "\n";
}

void Calendar::refresh() {
    auto it = events.begin();
    while (it != events.end()) {
        if ((*it)->isExpired()) {
            delete *it;
            it = events.erase(it);
        } else {
            ++it;
        }
    }
}

void Calendar::displayEvents() const {
    cout << "Current Events in Calendar:\n";
    for (const auto& event : events) {
        cout << event->getname() << " from " 
                  << event->getstarttime() << " to " << event->getendtime() << "\n";
    }
}
