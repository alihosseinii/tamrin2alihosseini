#ifndef CALENDAR_HPP
#define CALENDAR_HPP

#include "event.hpp"
#include <vector>

using namespace std;

class Calendar {
private:
    vector<event*> events;

public:
    ~Calendar();
    void addEvent(const string& name, int start, int end);
    void refresh();
    void displayEvents() const;
};

#endif
