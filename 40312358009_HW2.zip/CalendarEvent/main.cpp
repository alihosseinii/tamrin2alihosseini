#include <iostream>
#include <ctime>
#include "calendar.hpp"

using namespace std;

int main() {
    Calendar mycalendar;

    int now = time(nullptr);
    mycalendar.addEvent("meating", now + 3600, now + 7200);//از یه ساعت دیگه تا دوساعت دیگه
    mycalendar.addEvent("work", now + 10800, now + 6000); //سه ساعت بعد تا چهارساعت بعد
    mycalendar.addEvent("dinner", now + 5000 , now + 6000);// تداخل

    cout << "befor refresh \n";
    mycalendar.displayEvents();

    mycalendar.refresh();

    cout << "after refresh\n";
    mycalendar.displayEvents();
    return 0;

}